import hashlib
import os
from base64 import b64encode, b64decode
from Crypto.Cipher import AES
import tkinter as tk
from tkinter import simpledialog, messagebox

# AES 加密类
class AESCipher:
    def __init__(self, key):
        self.bs = AES.block_size
        self.key = hashlib.sha256(key.encode()).digest()

    def encrypt(self, raw):
        byte_data = self._pad(raw)
        iv = os.urandom(AES.block_size)
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        return b64encode(iv + cipher.encrypt(byte_data)).decode('utf-8')


    def decrypt(self, enc):
        enc = b64decode(enc)
        iv = enc[:16]
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        decrypted_bytes = cipher.decrypt(enc[16:])
        return self._unpad(decrypted_bytes)


    def _pad(self, s):
        # 将字符串转化为字节对象，以便进行padding
        byte_s = s.encode('utf-8')
        padding_size = self.bs - (len(byte_s) % self.bs)
        padding = bytes([padding_size]) * padding_size
        return byte_s + padding

    def _unpad(self, byte_s):
        # 使用最后一个字节的值作为padding的大小，并移除padding
        padding_size = byte_s[-1]
        return byte_s[:-padding_size].decode('utf-8')


# GUI 代码
# ... [不变的代码部分]

class App(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("AES Encryption Tool")
        self.geometry("1000x600")

        # Key 输入框
        self.key_label = tk.Label(self, text="Key:")
        self.key_label.pack(pady=10)
        self.key_entry = tk.Entry(self, show='*')
        self.key_entry.pack(fill=tk.X, padx=20, pady=5)

        # 左侧框架：原始文本
        self.left_frame = tk.Frame(self)
        self.left_frame.pack(side=tk.LEFT, padx=10, pady=10, fill=tk.BOTH, expand=True)

        self.input_label = tk.Label(self.left_frame, text="Original Text")
        self.input_label.pack(pady=10)

        self.input_text = tk.Text(self.left_frame, height=20, wrap=tk.WORD)
        self.input_text.pack(fill=tk.BOTH, padx=20, pady=5, expand=True)

        self.encrypt_button = tk.Button(self.left_frame, text="Encrypt", command=self.encrypt_text)
        self.encrypt_button.pack(fill=tk.X, padx=20, pady=5)

        # 右侧框架：加密/解密后的内容
        self.right_frame = tk.Frame(self)
        self.right_frame.pack(side=tk.RIGHT, padx=10, pady=10, fill=tk.BOTH, expand=True)

        self.result_label = tk.Label(self.right_frame, text="Encrypted/Decrypted Text")
        self.result_label.pack(pady=10)

        self.result_text = tk.Text(self.right_frame, height=20, wrap=tk.WORD)
        self.result_text.pack(fill=tk.BOTH, padx=20, pady=5, expand=True)

        self.decrypt_button = tk.Button(self.right_frame, text="Decrypt", command=self.decrypt_text)
        self.decrypt_button.pack(fill=tk.X, padx=20, pady=5)

    def encrypt_text(self):
        key = self.key_entry.get()
        text = self.input_text.get(1.0, tk.END).strip()

        if not key or not text:
            messagebox.showerror("Error", "Key or Text cannot be empty!")
            return

        cipher = AESCipher(key)

        encrypted = cipher.encrypt(text)
        self.result_text.delete(1.0, tk.END)
        self.result_text.insert(tk.END, encrypted)

    def decrypt_text(self):
        key = self.key_entry.get()
        encrypted_text = self.result_text.get(1.0, tk.END).strip()

        if not key or not encrypted_text:
            messagebox.showerror("Error", "Key or Text cannot be empty!")
            return

        cipher = AESCipher(key)
        try:
            decrypted = cipher.decrypt(encrypted_text)
            self.input_text.delete(1.0, tk.END)
            self.input_text.insert(tk.END, decrypted)
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")

if __name__ == "__main__":
    app = App()
    app.mainloop()